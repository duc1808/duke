<?php
    $host = "localhost";
    $user = "s102953643";
    $pwd = "";
    $sql_db = "s102953643_db";
?>
