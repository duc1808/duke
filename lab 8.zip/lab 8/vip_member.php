<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta name="description" content="web programming :: lab 8" />
    <meta name="keywords" content="web, programming" />
    <title>Web development - Lab 8</title>
</head>
<body>
    <h1>VIP member thing</h1>
    <ul>
        <li><a href="member_add_form.php">Add a member</a></li>
        <li><a href="member_display.php">View all members</a></li>
        <li><a href="member_search.php">Search for a member</a></li>
    </ul>
</body>
</html>
